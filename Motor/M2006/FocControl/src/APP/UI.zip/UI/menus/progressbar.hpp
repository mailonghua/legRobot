#ifndef __PROGRESSBAR_H__
#define __PROGRESSBAR_H__

class _progress_bar : public item {
};

#endif
