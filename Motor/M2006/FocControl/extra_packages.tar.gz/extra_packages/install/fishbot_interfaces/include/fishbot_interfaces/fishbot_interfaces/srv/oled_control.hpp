// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FISHBOT_INTERFACES__SRV__OLED_CONTROL_HPP_
#define FISHBOT_INTERFACES__SRV__OLED_CONTROL_HPP_

#include "fishbot_interfaces/srv/detail/oled_control__struct.hpp"
#include "fishbot_interfaces/srv/detail/oled_control__builder.hpp"
#include "fishbot_interfaces/srv/detail/oled_control__traits.hpp"

#endif  // FISHBOT_INTERFACES__SRV__OLED_CONTROL_HPP_
