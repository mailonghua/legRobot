//#include "Base/base.h"
#include "APP/UI/Base/base.h"
extern void app_entry(void*);

void UI_Main(void)
{
    u8g2_init();
    app_entry(0);
}