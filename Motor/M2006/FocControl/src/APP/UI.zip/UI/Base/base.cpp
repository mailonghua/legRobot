#include "base.h"

// u8g2_t u8g2;
U8G2_SSD1306_128X32_UNIVISION_F_SW_I2C     u8g2_var(U8G2_R2 , /* clock=*/ I2C_SCL_0, /* data=*/ I2C_SDA_0, /* reset=*/ U8X8_PIN_NONE);   // All Boards without Reset of the Display

uint8_t* buf_ptr;
uint16_t buf_len;

void u8g2_init()
{
    INFOLN("Start u8g2_init....");
    u8g2_var.begin();
    u8g2_var.setFont(u8g2_font_wqy12_t_chinese1);
    //u8g2_var.setFont(u8g2_font_t0_11_tf);
    // u8g2_var.clearBuffer();
    //  u8g2_var.drawStr(0,10,"Hello");
    //  u8g2_var.sendBuffer(); 
    // _clear();
    // _draw_str(0,10,"Hello Word");
    // _update();
    
    buf_ptr = u8g2_GetBufferPtr(u8g2_var.getU8g2());
    buf_len = 8 * u8g2_GetBufferTileHeight(u8g2_var.getU8g2()) * u8g2_GetBufferTileWidth(u8g2_var.getU8g2());
}

void effect_disappear()
{
    uint16_t i;

    for (i = 0; i < buf_len; i += 2) 
        buf_ptr[i] &= 0x55;
    
    _update();

    for (i = 1; i < buf_len; i += 2) 
        buf_ptr[i] &= 0xAA;
    
    _update();

    for (i = 0; i < buf_len; i += 2) 
        buf_ptr[i] &= 0x00;
    
    _update();

    for (i = 1; i < buf_len; i += 2) 
        buf_ptr[i] &= 0x00;
    
    _update();
}
