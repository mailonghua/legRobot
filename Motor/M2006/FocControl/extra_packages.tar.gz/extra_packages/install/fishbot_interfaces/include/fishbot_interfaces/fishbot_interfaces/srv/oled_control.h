// generated from rosidl_generator_c/resource/idl.h.em
// with input from fishbot_interfaces:srv/OledControl.idl
// generated code does not contain a copyright notice

#ifndef FISHBOT_INTERFACES__SRV__OLED_CONTROL_H_
#define FISHBOT_INTERFACES__SRV__OLED_CONTROL_H_

#include "fishbot_interfaces/srv/detail/oled_control__struct.h"
#include "fishbot_interfaces/srv/detail/oled_control__functions.h"
#include "fishbot_interfaces/srv/detail/oled_control__type_support.h"

#endif  // FISHBOT_INTERFACES__SRV__OLED_CONTROL_H_
