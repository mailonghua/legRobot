from fishbot_interfaces.srv._oled_control import OledControl  # noqa: F401
